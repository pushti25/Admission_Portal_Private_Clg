-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 16, 2026 at 02:39 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `admission_portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `admin`
--


-- --------------------------------------------------------

--
-- Table structure for table `admissions`
--

CREATE TABLE IF NOT EXISTS `admissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `course` varchar(100) NOT NULL,
  `document` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admissions`
--

INSERT INTO `admissions` (`id`, `name`, `mobile`, `course`, `document`, `created_at`, `email`, `password`) VALUES
(1, 'Admin', '1234567890', 'BE Computer Engineering', '1773922290_Pushti Resume.pdf', '2026-03-19 17:41:30', 'admin@gmail.com', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `contact_messages`
--

CREATE TABLE IF NOT EXISTS `contact_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `mobile` varchar(15) DEFAULT NULL,
  `message` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `contact_messages`
--

INSERT INTO `contact_messages` (`id`, `name`, `email`, `mobile`, `message`, `created_at`) VALUES
(1, 'Admin', 'admin@gmail.com', '1234567890', 'hello i have query', '2026-03-20 10:15:14');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE IF NOT EXISTS `courses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_slug` varchar(100) DEFAULT NULL,
  `course_name` varchar(100) DEFAULT NULL,
  `overview` text,
  `eligibility` text,
  `duration` varchar(50) DEFAULT NULL,
  `careers` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `course_slug` (`course_slug`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `course_slug`, `course_name`, `overview`, `eligibility`, `duration`, `careers`) VALUES
(1, 'computer', 'BE Computer Engineering', 'Focuses on software, hardware, AI, networking and cybersecurity.', '10+2 PCM, GUJCET/JEE, Min 45%', '4 Years (8 Semesters)', 'Software Engineer, AI Engineer, Data Scientist'),
(2, 'it', 'BE Information Technology', 'Focuses on software systems, cloud computing, cybersecurity.', '10+2 PCM, GUJCET/JEE, Min 45%', '4 Years', 'Software Developer, Cloud Engineer'),
(3, 'mechanical', 'BE Mechanical Engineering', 'Design, manufacturing, thermal systems and automobiles.', '10+2 PCM, GUJCET/JEE', '4 Years', 'Design Engineer, Production Engineer'),
(4, 'civil', 'BE Civil Engineering', 'Construction, structures, transportation, infrastructure.', '10+2 PCM, GUJCET/JEE', '4 Years', 'Site Engineer, Structural Engineer'),
(5, 'electronics', 'BE Electronics Engineering', 'Circuits, embedded systems, VLSI, IoT.', '10+2 PCM, GUJCET/JEE', '4 Years', 'Embedded Engineer, IoT Engineer'),
(6, 'electrical', 'BE Electrical Engineering', 'Power systems, electrical machines, control systems, renewable energy.', '10+2 PCM, GUJCET/JEE', '4 Years', 'Electrical Engineer, Power Engineer, Maintenance Engineer'),
(7, 'chemical', 'BE Chemical Engineering', 'Chemical processes, plant design, petrochemicals, process engineering.', '10+2 PCM, GUJCET/JEE', '4 Years', 'Chemical Engineer, Process Engineer, Plant Engineer'),
(8, 'aids', 'BE Artificial Intelligence & Data Science', 'Machine learning, AI, big data analytics, data mining.', '10+2 PCM, GUJCET/JEE', '4 Years', 'Data Scientist, AI Engineer, ML Engineer'),
(9, 'cyber', 'BE Cyber Security', 'Network security, ethical hacking, cryptography, cyber laws.', '10+2 PCM, GUJCET/JEE', '4 Years', 'Cyber Security Analyst, Ethical Hacker, Security Engineer'),
(10, 'automobile', 'BE Automobile Engineering', 'Vehicle design, engine systems, manufacturing, automotive technology.', '10+2 PCM, GUJCET/JEE', '4 Years', 'Automobile Engineer, Design Engineer'),
(11, 'mechatronics', 'BE Mechatronics Engineering', 'Robotics, automation, electronics + mechanical systems.', '10+2 PCM, GUJCET/JEE', '4 Years', 'Robotics Engineer, Automation Engineer'),
(12, 'biomedical', 'BE Biomedical Engineering', 'Medical devices, healthcare technology, bio-instrumentation.', '10+2 PCM (Biology optional)', '4 Years', 'Biomedical Engineer, Medical Equipment Engineer');

-- --------------------------------------------------------

--
-- Table structure for table `course_colleges`
--

CREATE TABLE IF NOT EXISTS `course_colleges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) DEFAULT NULL,
  `college_name` varchar(150) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `course_id` (`course_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `course_colleges`
--

INSERT INTO `course_colleges` (`id`, `course_id`, `college_name`, `city`) VALUES
(1, 1, 'LD College of Engineering', 'Ahmedabad'),
(2, 1, 'VGEC', 'Ahmedabad'),
(3, 1, 'Nirma University', 'Ahmedabad'),
(4, 2, 'Silver Oak University', 'Ahmedabad'),
(5, 2, 'Parul University', 'Vadodara'),
(6, 3, 'Government Engineering College', 'Rajkot'),
(7, 3, 'LD College of Engineering', 'Ahmedabad'),
(8, 4, 'Government Engineering College', 'Surat'),
(9, 4, 'Parul University', 'Vadodara'),
(10, 5, 'VGEC', 'Ahmedabad'),
(11, 5, 'Nirma University', 'Ahmedabad');
